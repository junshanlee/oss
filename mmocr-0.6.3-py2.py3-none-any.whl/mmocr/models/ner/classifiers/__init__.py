# Copyright (c) OpenMMLab. All rights reserved.
from .ner_classifier import NerClassifier

__all__ = ['NerClassifier']
