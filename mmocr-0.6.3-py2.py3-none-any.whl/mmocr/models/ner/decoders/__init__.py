# Copyright (c) OpenMMLab. All rights reserved.
from .fc_decoder import FCDecoder

__all__ = ['FCDecoder']
