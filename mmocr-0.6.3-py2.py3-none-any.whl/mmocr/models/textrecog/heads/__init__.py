# Copyright (c) OpenMMLab. All rights reserved.
from .seg_head import SegHead

__all__ = ['SegHead']
